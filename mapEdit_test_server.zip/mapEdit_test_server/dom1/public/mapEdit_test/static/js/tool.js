;
//--------------------------- 工具、几何计算函数 ---------------------------


// 更新坐标，矩阵转化(o: [object])：
function changeCoord(o) {
  // 坐标改变
  if (o.points) {
    var matrix = o.calcTransformMatrix();
    var transformedPoints = o.get("points")
      .map(function (p) {
        return new fabric.Point(
          p.x - o.pathOffset.x,
          p.y - o.pathOffset.y);
      })
      .map(function (p) {
        return fabric.util.transformPoint(p, matrix);
      });
    // console.log(transformedPoints);
    return transformedPoints;
  }
}

// 已知两条直角边，获取起点基于水平线的旋转了的角度
function getAngle(x1, x2, y1, y2) {
  let A = x2 - x1;
  let B = y2 - y1;
  let angle = 0;
  angle = Math.atan(B / A) / (Math.PI / 180);
  // angle = Math.round(angle);
  console.log(angle);
  return angle;
}
// getAngle(20, 50, 0, 20);

// 圆形转多边形：(geojson数据格式不支持圆形，用多边形模仿圆形)
/**
 * 
 * @param {object} center (圆的中心坐标)
 * @param {number} r (圆的半径)
 * @param {number} numb (多边形的点的数量)
 * 
 */
function circleToPolygon(center, r, numb) {
  let points = [];
  let degree = 360 / numb;
  for (var i = 0; i < numb; i++) {
    let x = center.x + Math.cos(Math.PI * 2 / 360 * degree * (i + 1)) * r;
    let y = center.y + Math.sin(Math.PI * 2 / 360 * degree * (i + 1)) * r;
    points.push({ x, y });
  }
  return points;
}

//高斯投影坐标反算成经纬度：
function GaussToBL(X, Y) {
  let ProjNo;
  let ZoneWide; //带宽
  let output = new Array(2);
  let longitude1, latitude1, longitude0, X0, Y0, xval, yval; //latitude0,
  let e1, e2, f, a, ee, NN, T, C, M, D, R, u, fai, iPI;
  iPI = 3.14159265358979324 / 180.0; 3.1415926535898 / 180.0;
  // a = 6378245.0; f = 1.0/298.3; //54年北京坐标系参数
  a = 6378140.0; f = 1.0 / 298.257; //80年西安坐标系参数
  ZoneWide = 6; // 6度带宽
  ProjNo = parseInt(X / 1000000); //查找带号
  longitude0 = (ProjNo - 1) * ZoneWide + ZoneWide / 2;
  longitude0 = longitude0 * iPI; //中央经线


  X0 = ProjNo * 1000000 + 500000;
  Y0 = 0;
  xval = X - X0; yval = Y - Y0; //带内大地坐标
  e2 = 2 * f - f * f;
  e1 = (1.0 - Math.sqrt(1 - e2)) / (1.0 + Math.sqrt(1 - e2));
  ee = e2 / (1 - e2);
  M = yval;
  u = M / (a * (1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 * e2 * e2 / 256));
  fai = u + (3 * e1 / 2 - 27 * e1 * e1 * e1 / 32) * Math.sin(2 * u) + (21 * e1 * e1 / 16 - 55 * e1 * e1 * e1 * e1 / 32) * Math.sin(4 * u) + (151 * e1 * e1 * e1 / 96) *
    Math.sin(6 * u) + (1097 * e1 * e1 * e1 * e1 / 512) * Math.sin(8 * u);
  C = ee * Math.cos(fai) * Math.cos(fai);
  T = Math.tan(fai) * Math.tan(fai);
  NN = a / Math.sqrt(1.0 - e2 * Math.sin(fai) * Math.sin(fai));
  R = a * (1 - e2) / Math.sqrt((1 - e2 * Math.sin(fai) * Math.sin(fai)) * (1 - e2 * Math.sin(fai) * Math.sin(fai)) * (1 - e2 * Math.sin
    (fai) * Math.sin(fai)));
  D = xval / NN;
  //计算经度(Longitude) 纬度(Latitude)
  longitude1 = longitude0 + (D - (1 + 2 * T + C) * D * D * D / 6 + (5 - 2 * C + 28 * T - 3 * C * C + 8 * ee + 24 * T * T) * D
    * D * D * D * D / 120) / Math.cos(fai);
  latitude1 = fai - (NN * Math.tan(fai) / R) * (D * D / 2 - (5 + 3 * T + 10 * C - 4 * C * C - 9 * ee) * D * D * D * D / 24
    + (61 + 90 * T + 298 * C + 45 * T * T - 256 * ee - 3 * C * C) * D * D * D * D * D * D / 720);
  //转换为度 DD
  output[0] = longitude1 / iPI;
  output[1] = latitude1 / iPI;
  return output;
}


//经纬度=>高斯投影：
function BLToGauss(longitude, latitude) {
  let ProjNo = 0;
  let ZoneWide; //带宽
  let ret = Array(2);
  let longitude1, latitude1, longitude0, latitude0, X0, Y0, xval, yval;
  let a, f, e2, ee, NN, T, C, A, M, iPI;
  iPI = 0.0174532925199433; 3.1415926535898 / 180.0;
  ZoneWide = 6; //6度带宽
  // a=6378245.0; f=1.0/298.3; //54年北京坐标系参数
  a = 6378140.0; f = 1 / 298.257; //80年西安坐标系参数
  ProjNo = parseInt(longitude / ZoneWide);
  longitude0 = ProjNo * ZoneWide + ZoneWide / 2;
  longitude0 = longitude0 * iPI;
  latitude0 = 0;
  longitude1 = longitude * iPI; //经度转换为弧度
  latitude1 = latitude * iPI; //纬度转换为弧度
  e2 = 2 * f - f * f;
  ee = e2 * (1.0 - e2);
  NN = a / Math.sqrt(1.0 - e2 * Math.sin(latitude1) * Math.sin(latitude1));
  T = Math.tan(latitude1) * Math.tan(latitude1);
  C = ee * Math.cos(latitude1) * Math.cos(latitude1);
  A = (longitude1 - longitude0) * Math.cos(latitude1);
  M = a * ((1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 * e2 * e2 / 256) * latitude1 - (3 * e2 / 8 + 3 * e2 * e2 / 32 + 45 * e2 * e2
    * e2 / 1024) * Math.sin(2 * latitude1)
    + (15 * e2 * e2 / 256 + 45 * e2 * e2 * e2 / 1024) * Math.sin(4 * latitude1) - (35 * e2 * e2 * e2 / 3072) * Math.sin(6 * latitude1));
  xval = NN * (A + (1 - T + C) * A * A * A / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ee) * A * A * A * A * A / 120);
  yval = M + NN * Math.tan(latitude1) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A * A * A * A / 24
    + (61 - 58 * T + T * T + 600 * C - 330 * ee) * A * A * A * A * A * A / 720);
  X0 = 1000000 * (ProjNo + 1) + 500000;
  Y0 = 0;
  xval = xval + X0; yval = yval + Y0;
  ret[0] = xval;
  ret[1] = yval;

  return ret;
}
