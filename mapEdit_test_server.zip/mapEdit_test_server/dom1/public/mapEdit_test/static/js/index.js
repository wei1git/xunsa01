

var saveMapUrl = 'http://192.168.31.38:3000/api/saveMap';
var getCanvasUrl = '请求获取该楼层的canvas数据';

var floor = 1; //默认编辑的是一楼
// let ref = window.parent.document.getElementById("workspace").contentWindow.location.href;
// let arr = ref.split('/');
// // console.log(arr, arr.length);
// console.log(arr[arr.length - 1]);
// floor = arr[arr.length - 1];

fabric.Canvas.prototype.getWatermark = function () {
  var object = null,
    objects = this.getObjects();

  for (var i = 0, len = this.size(); i < len; i++) {
    if (objects[i].myType && objects[i].myType === 'watermark') {
      object = objects[i];
      break;
    }
  }
  return object;
};

fabric.Canvas.prototype.setWatermark = function () {
  var watermark = this.getWatermark();
  this.remove(watermark);
};

var canvasData = {};

var drawing = false; //是否正在画
var drawType = null; //绘制的图形类型

var drawingObject = null; //当前绘制对象
var moveCount = 1; //绘制移动计数器
var mouseFrom = {};
var mouseTo = {};

//polygon 相关参数
var temPointArray = []; //当前绘制过程产生的临时点的 集合
var temLine = {}; //当前绘制过程需要产生的临时的辅助直线
var temLineArray = []; //当前绘制过程需要产生的临时的辅助直线 集合
var activeShape = false;
var activeLine = "";
var polygonMode = false;


//fabricjs控制器样式修改：
fabric.Object.prototype.set({
  // borderColor: 'blue',
  cornerColor: 'blue', //激活状态角落图标的填充颜色
  cornerStrokeColor: "", //激活状态角落图标的边框颜色
  borderOpacityWhenMoving: 1,
  borderScaleFactor: 1,
  cornerSize: 8,
  cornerStyle: "circle", //rect,circle
  centeredScaling: false, //角落放大缩小是否是以图形中心为放大原点
  centeredRotation: true, //旋转按钮旋转是否是左上角为圆心旋转
  transparentCorners: false, //激活状态角落的图标是否透明
  rotatingPointOffset: 20, //旋转距旋转体的距离
  originX: "center",
  originY: "center",
  lockUniScaling: false, //只显示四角的操作
  hasRotatingPoint: true, //是否显示旋转按钮
  selectionDashArray: [5, 5]
});

// 手动设置选中状态: canvas.setActiveObject(obj);

// 添加自定义控制器（删除）:
var deleteIcon = "data:image/svg+xml,%3C%3Fxml version='1.0' encoding='utf-8'%3F%3E%3C!DOCTYPE svg PUBLIC '-//W3C//DTD SVG 1.1//EN' 'http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd'%3E%3Csvg version='1.1' id='Ebene_1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' width='595.275px' height='595.275px' viewBox='200 215 230 470' xml:space='preserve'%3E%3Ccircle style='fill:%23F44336;' cx='299.76' cy='439.067' r='218.516'/%3E%3Cg%3E%3Crect x='267.162' y='307.978' transform='matrix(0.7071 -0.7071 0.7071 0.7071 -222.6202 340.6915)' style='fill:white;' width='65.545' height='262.18'/%3E%3Crect x='266.988' y='308.153' transform='matrix(0.7071 0.7071 -0.7071 0.7071 398.3889 -83.3116)' style='fill:white;' width='65.544' height='262.179'/%3E%3C/g%3E%3C/svg%3E";
var img = document.createElement('img');
img.src = deleteIcon;
function deleteObject(eventData, target) {
  // canvas.remove(canvas.getActiveObject());

  let o = canvas.getActiveObject();
  if (o.ownData && o.ownData.father) {
    let name = o.ownData.name;
    let fatherName = o.ownData.father;

    canvas.getObjects().map(function (itemObj) { //根据它的父元素名字来查找它的父元素(绑定的桌子元素)
      if (itemObj.ownData && itemObj.ownData.name && itemObj.ownData.name == fatherName) {
        if (itemObj.ownData.chairs_num) {
          let index = itemObj.ownData.chairs_num.indexOf(name);
          itemObj.ownData.chairs_num.splice(index, 1); //删除这个桌子绑定的椅子数组中对应的椅子
        }
      }
    });
  }
  canvas.remove(o);
  $('.edit_panel').hide();
  canvas.requestRenderAll();
}
function renderIcon(ctx, left, top, styleOverride, fabricObject) {
  var size = this.cornerSize;
  ctx.save();
  ctx.translate(left, top);
  ctx.rotate(fabric.util.degreesToRadians(fabricObject.angle));
  ctx.drawImage(img, -size / 2, -size / 2, size, size);
  ctx.restore();
}
fabric.Object.prototype.controls.deleteControl = new fabric.Control({
  x: 0.5,
  y: -0.5,
  offsetY: -16,
  cursorStyle: 'pointer',
  mouseUpHandler: deleteObject,
  render: renderIcon,
  cornerSize: 24
});


// 初始化画布：
var canvas = new fabric.Canvas('box');
initCanvas();
function initCanvas() {
  // 鼠标滚动画布放大缩小
  canvas.on("mouse:wheel", function (opt) {
    console.log('画布放大缩小')
    // console.log(opt);
    var delta = opt.e.deltaY;
    var curZoom = canvas.getZoom();
    curZoom *= 0.999 ** delta;
    if (curZoom > 3) curZoom = 3; //最大是原来的3倍
    if (curZoom < 0.2) curZoom = 0.2;  //最小为原来的1/5
    canvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, curZoom);

    opt.e.preventDefault();
    opt.e.stopPropagation();
  });

  // 画布鼠标点击事件：
  canvas.on('mouse:down', function (options) {
    // console.log('option==>', options)
    var evt = options.e;
    if (evt.altKey === true) {
      this.isDragging = true;
      this.selection = false;
      this.lastPosX = evt.clientX;
      this.lastPosY = evt.clientY;
    }
    if (evt.ctrlKey === true) { //Ctrl + 点击 选中
      console.log('ctrl + 点击');
      // var pointer = canvas.getPointer(evt.originalEvent);
      // var objects = canvas.getObjects();
      // for (var i = objects.length - 1; i >= 0; i--) {
      //   var object = objects[i];
      //   //判断该对象是否在鼠标点击处
      // }
    }
    if (options.target) { //点击目标
      // console.log('有对象被点击咯! ', options.target);
      if (!drawing) { //不是在画东西
        if (options.target.selectable) {

          if (options.target.type && options.target.type == 'image') {
            //点的是图标，就不用展示编辑面板了，图标只能移动没有属性和编辑
            $('.menu .icon_list').hide();
            $('.menu .thing_list').hide();
            $('.menu .edit_panel').hide();
            return;
          }

          initPanel(options.target);
          $('.menu .thing_list').hide();
          $('.menu .edit_panel').show();
        }
      }
    } else { //点击空白处
      $('.menu .edit_panel').hide();
      $('.menu .icon_list').hide();

    }
    if (drawing) { //正在画东西
      //取消选中当前活跃目标（避免误操作、多边形合并不了的问题，但还是能移动底部的目标）
      canvas.discardActiveObject();
      canvas.requestRenderAll();

      if (drawType == 'polygon' || drawType == 'wall') { //正在画的是多边形/墙体边框
        // 先判断当前点的数量是否大于1个
        if (temPointArray.length > 1) {
          // 如果点击的是第一个点红点，就闭合并添加成多边形
          if (options.target && options.target.id == temPointArray[0].id) {
            // console.log(options.target);
            generatePolygon();
          } else if (temPointArray[0].left + 5 > evt.layerX && temPointArray[0].left - 5 < evt.layerX) {
            //如果点击的地方在红点附近，也闭合多边形
            if (temPointArray[0].top + 5 > evt.layerY && temPointArray[0].top - 5 < evt.layerY) {
              generatePolygon();
            }
          }
        }
        //如果不是点击的第一个点，那就继续添加点
        if (polygonMode) {
          addPoint(options);
        }
      }
    }
  });
  // 画布鼠标抬起事件
  canvas.on("mouse:up", function (e) {
    // console.log('点击弹起事件')
    this.setViewportTransform(this.viewportTransform);
    this.isDragging = false;
    this.selection = true;
    drawingObject = null;
  });
  // 画布上鼠标移动事件
  canvas.on("mouse:move", function (options) {
    // console.log('画布上鼠标移动事件')
    var e = options.e;
    if (this.isDragging) { // 挪动画布
      var vpt = this.viewportTransform;
      vpt[4] += e.clientX - this.lastPosX;
      vpt[5] += e.clientY - this.lastPosY;
      this.requestRenderAll();
      this.lastPosX = e.clientX;
      this.lastPosY = e.clientY;
    } else {
      if (moveCount % 2 && !drawing) {
        //减少绘制频率
        return;
      }
      moveCount++;
      var xy = options.pointer || this.transformMouse(options.e.offsetX, options.e.offsetY);
      // console.log(xy);
      // mouseTo.x = xy.x;
      // mouseTo.y = xy.y;
      mouseTo = xy;
      // 多边形与文字框特殊处理
      if (drawType != "text" || drawType != "polygon") {
        // drawing(options);
        if (drawingObject) {
          canvas.remove(drawingObject);
        }

      }
      if (drawType == "polygon" || drawType == "wall") {
        if (activeLine && activeLine.class == "line") {
          var pointer = canvas.getPointer(e.e);
          activeLine.set({ x2: pointer.x, y2: pointer.y });
          var points = activeShape.get("points");
          points[temPointArray.length] = {
            x: pointer.x,
            y: pointer.y,
            zIndex: 1
          };
          activeShape.set({
            points: points
          });
          canvas.renderAll();
        }
        canvas.renderAll();
      }
    }
  });
  // 监听目标被编辑修改后：
  canvas.on('object:modified', (e) => {
    let o = e.target;
    // console.log("被编辑的元素位置改变的时候+++》", o._objects); // 是否为一个组

    if (o._objects && o._objects.length > 0) { // 一个组
      o._objects.forEach(function (item) {
        // console.log(item);
        item.setCoords(); //刷新布局属性
        let newPoints = changeCoord(item);
        item.curPoints = newPoints;
      });
    } else { // 单个对象
      // console.log("单个对象==》")
      let newPoints = changeCoord(o);
      // console.log('changeCoord===>', changeCoord(o))
      o.curPoints = newPoints;
      o.setCoords();
      // console.log('263行修改后：', o);
    }

  });
  // 监听目标移动之后：
  canvas.on('object:moved', (e) => {
    // console.log('监听目标移动事件')
    // console.log(e);
  });
  // 监听目标缩放操作时：
  canvas.on('object:scaling', (e) => {

  });
  // 监听目标缩放之后：
  canvas.on('object:scaled', (e) => {
    // console.log(e);
    // let o = e.target;
    // // 描边宽度保持不变：
    // if (!o.strokeWidthUnscaled && o.strokeWidth) {
    //   o.strokeWidthUnscaled = o.strokeWidth;
    // }
    // if (o.strokeWidthUnscaled) {
    //   o.strokeWidth = o.strokeWidthUnscaled / o.scaleX;
    // }
  });
  // 监听目标旋转操作时：
  canvas.on('object:rotating', (e) => {

  });
  // 监听目标旋转操作之后：
  canvas.on('object:rotated', (e) => {

  });
}

// 获取当前视图下中心的实际坐标：
function viewCenter() {
  let zoom = canvas.getZoom();
  // console.log(fabric.util.invertTransform(canvas.viewportTransform), '==>', canvas.viewportTransform, (canvas.height / zoom) / 2)
  return {
    x: fabric.util.invertTransform(canvas.viewportTransform)[4] + (canvas.width / zoom) / 2,
    y: fabric.util.invertTransform(canvas.viewportTransform)[5] + (canvas.height / zoom) / 2
  }
}

// 菜单按钮绑定事件：
// 添加圆形
$('.menu .add_btn1').click(function () {
  // console.log(viewCenter());
  let canvasCenter = viewCenter();
  // console.log('圆形的位置在哪=》', canvasCenter)
  drawing = false;
  drawType = null;
  let center = { x: canvasCenter.x, y: canvasCenter.y };
  let r = 50;
  let numb = 64;
  let points = circleToPolygon(center, r, numb);
  // console.log("320行point++》", points)
  let polygon = new fabric.Polygon(points, {
    stroke: '#000',
    strokeWidth: 1,
    fill: '#C0E9FC',
    curPoints: "0",
    opacity: 1,
    strokeUniform: true, //描边宽度不变
    perPixelTargetFind: true //点击像素才会选中
  });
  // 自定义属性保存时候避免丢失
  polygon.toObject = (function (toObject) {
    return function () {
      return fabric.util.object.extend(toObject.call(this), {
        curPoints: this.curPoints || null,
        ownData: this.ownData || null
      });
    };
  })(polygon.toObject);
  canvas.add(polygon);
  // canvas.bringToFront(polygon);
});
// 添加矩形
$('.menu .add_btn2').click(function () {
  let canvasCenter = viewCenter();
  drawing = false;
  drawType = null;

  let points = [
    { x: canvasCenter.x, y: canvasCenter.y },
    { x: canvasCenter.x + 50, y: canvasCenter.y },
    { x: canvasCenter.x + 50, y: canvasCenter.y + 50 },
    { x: canvasCenter.x, y: canvasCenter.y + 50 }
  ]
  let polygon = new fabric.Polygon(points, {
    stroke: '#000',
    strokeWidth: 1,
    fill: '#C0E9FC',
    opacity: 1,
    preserveObjectStacking: true,
    lockScalingFlip: true,
    strokeUniform: true //描边宽度不变
  });
  // 自定义属性保存时候避免丢失
  polygon.toObject = (function (toObject) {
    return function () {
      return fabric.util.object.extend(toObject.call(this), {
        curPoints: this.curPoints || null,
        ownData: this.ownData || null
      });
    };
  })(polygon.toObject);
  canvas.add(polygon);
  // canvas.bringToFront(polygon);

});
// 添加三角形
$('.menu .add_btn3').click(function () {
  drawing = false;
  drawType = null;
  let points = [
    { x: 100, y: 100 },
    { x: 150, y: 150 },
    { x: 50, y: 150 }
  ]
  let polygon = new fabric.Polygon(points, {
    stroke: '#000',
    strokeWidth: 1,
    fill: null,
    opacity: 1
  });
  polygon.toObject = (function (toObject) {
    return function () {
      return fabric.util.object.extend(toObject.call(this), {
        curPoints: this.curPoints || null,
        ownData: this.ownData || null
      });
    };
  })(polygon.toObject);
  canvas.add(polygon);
  // canvas.bringToFront(polygon);
});
// 添加多边形
$('.menu .add_btn4').click(function () {
  drawing = true;
  drawType = 'polygon';
  polygonMode = true;
  temPointArray = new Array();  // 顶点集合
  temLineArray = new Array();  //线集合
  canvas.isDrawingMode = false;
});
// 选择物件
$('.menu .add_btn5').click(function () {
  console.log('点击了添加物件');
  $('.edit_panel').hide();
  $('.thing_list').show();
});
// 添加图标
$('.thing_list .item').click(function () {
  console.log($(this).children('img'));
  let canvasCenter = viewCenter();
  let curIconSrc = $($(this).children('img')[0]).attr('src');
  let imgElement = $(this).children('img')[0];
  let imgInstance = new fabric.Image(imgElement, {
    // cornerSize: 6, //控制器方块大小
    left: canvasCenter.x,
    top: canvasCenter.y,
    opacity: 1,
    lockScalingX: true,
    lockScalingY: true, //锁定大小缩放
    lockRotation: true, //锁定旋转
    ownData: {
      curIconSrc
    }
  });
  // imgInstance.hasControls = imgInstance.hasBorders = false; //控制器和控制器边线
  imgInstance.hasBorders = false;
  // 自定义属性保存时候避免丢失
  imgInstance.toObject = (function (toObject) {
    return function () {
      return fabric.util.object.extend(toObject.call(this), {
        curPoints: this.curPoints || null,
        ownData: this.ownData || null
      });
    };
  })(imgInstance.toObject);

  canvas.add(imgInstance);
  canvas.bringToFront(imgInstance);
});
// 绘制墙体、边框
$('.menu .add_btn6').click(function () {
  drawing = true;
  drawType = 'wall';
  polygonMode = true;
  temPointArray = new Array();  // 顶点集合
  temLineArray = new Array();  //线集合
  canvas.isDrawingMode = false;
});

// 添加点：
function addPoint(e) {
  console.log(e);
  var pos = canvas.getPointer(e.e);

  var random = Math.floor(Math.random() * 10000);
  var id = new Date().getTime() + random;
  var circle = new fabric.Circle({
    radius: 5 / canvas.getZoom(),
    fill: "#ffffff",
    stroke: "#333333",
    strokeWidth: 0.5,
    // left: (e.pointer.x || e.e.layerX) / canvas.getZoom(),
    // top: (e.pointer.y || e.e.layerY) / canvas.getZoom(),
    // left: lastzoomPoint.x + (e.pointer.x - zoomPoint.x - relativeMouseX) / canvas.getZoom(),
    // top: lastzoomPoint.y + (e.pointer.y - zoomPoint.y - relativeMouseY) / canvas.getZoom(),
    left: pos.x,
    top: pos.y,
    selectable: false,
    hasBorders: false,
    hasControls: false,
    originX: "center",
    originY: "center",
    id: id,
    objectCaching: false
  });
  if (temPointArray.length == 0) { //第一个点设为红色好分辨
    circle.set({
      fill: "red",
      zIndex: 999
    });
  }
  var points = [
    // (e.pointer.x || e.e.layerX) / canvas.getZoom(),
    // (e.pointer.y || e.e.layerY) / canvas.getZoom(),
    // (e.pointer.x || e.e.layerX) / canvas.getZoom(),
    // (e.pointer.y || e.e.layerY) / canvas.getZoom()
    // lastzoomPoint.x + (e.pointer.x - zoomPoint.x - relativeMouseX) / canvas.getZoom(),
    // lastzoomPoint.y + (e.pointer.y - zoomPoint.y - relativeMouseY) / canvas.getZoom(),
    // lastzoomPoint.x + (e.pointer.x - zoomPoint.x - relativeMouseX) / canvas.getZoom(),
    // lastzoomPoint.y + (e.pointer.y - zoomPoint.y - relativeMouseY) / canvas.getZoom()
    pos.x,
    pos.y,
    pos.x,
    pos.y
  ];
  // console.log(points);
  temLine = new fabric.Line(points, {
    strokeWidth: 2 / canvas.getZoom(),
    fill: "#999999",
    stroke: "#999999",
    class: "line",
    originX: "center",
    originY: "center",
    selectable: false,
    hasBorders: false,
    hasControls: false,
    evented: false,
    objectCaching: false
  });

  if (activeShape) {
    // var pos = canvas.getPointer(e.e);
    console.log(pos);
    var points = activeShape.get("points");
    points.push({
      x: pos.x,
      y: pos.y
    });
    var polygon = new fabric.Polygon(points, {
      stroke: "#333333",
      strokeWidth: 1 / canvas.getZoom(),
      fill: "#cccccc",
      opacity: 0.3,
      selectable: false,
      hasBorders: false,
      hasControls: false,
      evented: false,
      objectCaching: false
    });
    canvas.remove(this.activeShape);
    canvas.add(polygon);
    activeShape = polygon;
    canvas.renderAll();
  } else {
    var polyPoint = [
      {
        // x: (e.pointer.x || e.e.layerX) / canvas.getZoom(),
        // y: (e.pointer.y || e.e.layerY) / canvas.getZoom()
        // x: lastzoomPoint.x + (e.pointer.x - zoomPoint.x - relativeMouseX) / canvas.getZoom(),
        // y: lastzoomPoint.y + (e.pointer.y - zoomPoint.y - relativeMouseY) / canvas.getZoom()
        x: pos.x,
        y: pos.y
      }
    ];
    var polygon = new fabric.Polygon(polyPoint, {
      stroke: "#333333",
      strokeWidth: 1 / canvas.getZoom(),
      fill: "#cccccc",
      opacity: 0.3,
      selectable: false,
      hasBorders: false,
      hasControls: false,
      evented: false,
      objectCaching: false
    });
    activeShape = polygon;
    canvas.add(polygon);
  }
  activeLine = this.temLine;

  temPointArray.push(circle);
  temLineArray.push(temLine);
  canvas.add(temLine);
  canvas.add(circle);
}

// 构造多边形：
function generatePolygon() {
  console.log('generatePolygon');
  var points = new Array();
  temPointArray.map((point, index) => {
    points.push({
      x: point.left,
      y: point.top
    });
    canvas.remove(point);
  });
  temLineArray.map((line, index) => {
    canvas.remove(line);
  });
  canvas.remove(activeShape).remove(activeLine);
  var polygon = new fabric.Polygon(points, {
    stroke: '#000',
    strokeWidth: 1,
    fill: '#C0E9FC',
    opacity: 1,
    hasBorders: true,
    hasControls: true,
    strokeUniform: true,
    perPixelTargetFind: true
  });
  // 自定义属性保存时候避免丢失:
  polygon.toObject = (function (toObject) {
    return function () {
      return fabric.util.object.extend(toObject.call(this), {
        curPoints: this.curPoints || null,
        ownData: this.ownData || null
      });
    };
  })(polygon.toObject);

  if (drawType == 'wall') {
    //如果是墙体
    polygon.set({
      stroke: '#666',
      strokeWidth: 2,
      fill: '#aaa'
    });
  }

  canvas.add(polygon);
  activeLine = null;
  activeShape = null;
  polygonMode = false;
  drawing = false;
  drawType = null;
}

//右键取消进行中的绘画：
//在canvas上层对象上添加右键事件监听
$(".upper-canvas").contextmenu(onContextmenu);
function onContextmenu(e) {
  if ((drawType == 'polygon' || drawType == 'wall') && drawing) {
    console.log('取消');
    temPointArray.map((point, index) => {
      canvas.remove(point);
    });
    temLineArray.map((line, index) => {
      canvas.remove(line);
    });
    canvas.remove(activeShape).remove(activeLine);
    activeLine = null;
    activeShape = null;
    polygonMode = false;
    drawing = false;
    drawType = null;
  }

  e.preventDefault();
}


$('.menu .tab .attr').click(function () {
  $('.menu .tab .item').removeClass('active');
  $(this).addClass('active');
  $('.edit_panel .content').hide();
  $('.edit_panel .attr_content').show();
});
$('.menu .tab .son').click(function () {
  $('.menu .tab .item').removeClass('active');
  $(this).addClass('active');
  $('.edit_panel .content').hide();
  $('.edit_panel .son_content').show();
});

// 菜单编辑面板初始化
function initPanel(obj) {
  refreshAttr(obj);
  regreshSonData(obj);
}

// 菜单编辑面板 属性数据 刷新
function refreshAttr(data) {
  // 先删除清空
  $('.menu .edit_panel>.title').text('');
  $('.attr_content input').val('');

  if (data.type && data.type == 'image') {
    return;
  }

  if (data.fill) {
    $('.attr_content .fill input').val(data.fill);
  }
  if (data.stroke) {
    $('.attr_content .stroke input').val(data.stroke);
  }
  if (data.strokeWidth) {
    let w = data.strokeWidth * (data.scaleX || 1);
    $('.attr_content .strokeW input').val(w);
  }
}

// 菜单编辑面板 ownData自定义属性（子组件属性数据） 刷新
function regreshSonData(data) {
  // 先删除清空
  $('.son_content .num_1>input').val('');
  $('.edit_panel .son_content').children('.num_2').remove();
  $('.menu .icon_list').hide();
  $('.edit_panel .cur_icon img').attr('src', null);
  $('.edit_panel .selectType').val('none');
  $('.son_content .selectType').removeAttr('disabled');
  $('.edit_panel .add').hide();
  $('.edit_panel .son_content .father').hide();

  if (!data.ownData) {
    return;
  }
  let ownData = data.ownData;
  // if (ownData.curIcon) {
  //   $('.edit_panel .cur_icon img').attr('icon', ownData.curIcon);
  // }
  // if (ownData.curIconSrc) {
  //   $('.edit_panel .cur_icon img').attr('src', ownData.curIconSrc);
  // }
  if (ownData.name) {
    $('.edit_panel>.title').text(ownData.name);
    $('.son_content .num_1>input').val(ownData.name);
  }
  if (ownData.type) { //根据不同类型，编辑面板而不同
    $('.son_content .selectType').val(ownData.type);

    if (ownData.type == 'desk') {
      $('.edit_panel .add').css('display', 'flex');
    }

    // 房间和椅子类型都不能再设置成别的类型了：
    if (ownData.type == 'chair') {
      $('.son_content .selectType').attr('disabled', 'disabled');
      $('.son_content .father').show();
      $('.son_content .father>span').text(ownData.father);
    }
    else if (ownData.type == 'room') {
      $('.son_content .selectType').attr('disabled', 'disabled');
    }
    else {
      $('.son_content .selectType').removeAttr('disabled');
    }

  }

  if (ownData.chairs_num && ownData.chairs_num.length > 0) {
    let chairs_num = ownData.chairs_num;
    let html = `<div class="row num_2">
                  <span class="title">椅子编号：</span>
                  <input type="text" />
                  <button class="delete">删除</button>
                </div>`;
    chairs_num.forEach(function (e, index) {
      $('.son_content .add').before(html);
      $($('.son_content .num_2>input')[index]).val(e);
    });
    // 删除其中一项椅子及编号：
    $('.son_content .row .delete').click(function () {
      // console.log('remove');
      $(this).parent().remove();
    });
  }
}

// 编辑物品面板操作
// 上传底图：
function uploadBaseMap(file, value) {
  // console.log(file[0], value);

  var center = canvas.getCenter();
  canvas.setBackgroundImage('./static/images/baseMap.png',
    canvas.renderAll.bind(canvas), {
    scaleX: 1,
    scaleY: 1,
    top: center.top,
    left: center.left,
    originX: 'center',
    originY: 'center'
  });
  console.log('add baseMap');
}
// 选择设置区域、物品类型：
$('.edit_panel .selectType').change(function (data) {
  var value = $('.edit_panel .selectType option:selected').val();
  // console.log(value, data);
  if (value == 'desk') {
    $('.edit_panel .add').css('display', 'flex');
  } else {
    $('.edit_panel .add').hide();
  }
});

// 改变填充颜色：
function changeFillColor() {
  let newColor = $('.edit_panel .fill input').val();
  console.log(newColor);

  canvas.getActiveObject().set({
    fill: newColor
  });
  canvas.renderAll();
}
// 改变填充颜色：
function changeStrokeColor() {
  let newColor = $('.edit_panel .stroke input').val();
  console.log(newColor, canvas.getActiveObject(), 1234);


  canvas.getActiveObject().set({
    stroke: newColor
  });
  canvas.renderAll();
}
// 改变描边宽度：
function changeStrokeW() {
  let newWidth = $('.edit_panel .strokeW input').val();

  let o = canvas.getActiveObject();
  if (!o.strokeWidthUnscaled && o.strokeWidth) {
    o.strokeWidthUnscaled = o.strokeWidth = newWidth;
  }
  if (o.strokeWidthUnscaled) {
    o.strokeWidthUnscaled = newWidth;
    o.strokeWidth = o.strokeWidthUnscaled / o.scaleX;
  }


  // console.log(newWidth, o.scaleX, o.strokeWidth);

  canvas.renderAll();
}
// 为物品添加椅子及编号：
$('.edit_panel .add button').click(function () {
  if ($(this).parent().parent().children('.num_2').length >= 12) {
    alert('一张桌子最多只能添加12只椅子！');
    return;
  }
  //动态添加椅子选项
  let html = `<div class="row num_2">
                  <span class="title">椅子编号：</span>
                  <input type="text" />
                  <button class="delete">删除</button>
                </div>`;
  $(this).parent().before(html);
  // 删除其中一项椅子及编号：
  $('.edit_panel .row .delete').click(function () {
    // console.log('remove');
    $(this).parent().remove();
  });
});
// 为物品或区域选择代表图标：
$('.edit_panel .select_icon button').click(function () {
  $('.icon_list').show();
});
$('.icon_list .content .item').click(function () {
  let curIcon = $(this).data('icon');
  let curIconSrc = $($(this).children('img')[0]).attr('src');
  $('.edit_panel .cur_icon img').attr('src', curIconSrc);
  console.log('cur_icon: ' + curIcon);
  $('.edit_panel .cur_icon img').data('icon', curIcon);
});

// 确定：
$('.edit_panel .footer>.set').click(function () {
  let curIcon = $('.edit_panel .cur_icon img').data('icon');
  let curIconSrc = $('.edit_panel .cur_icon img').attr('src');
  let name = $('.edit_panel .num_1 input').val(); //名字/编号
  let type = $('.edit_panel .selectType option:selected').attr('value'); //物品类型
  let chairs_num = []; //椅子编号集合

  //遍历画布里的对象，将所有绑定该桌子的椅子元素删除
  canvas.getObjects().map(function (o) {
    // console.log(o);
    if (o.ownData && o.ownData.father && o.ownData.father == name) {
      canvas.remove(o);
    }
  });

  // 先保存数据
  let o = canvas.getActiveObject();
  let ownData = o.ownData || {};
  ownData.name = name;
  ownData.type = type;
  ownData.curIcon = curIcon;
  ownData.curIconSrc = curIconSrc;
  if (type == 'desk') {
    ownData.chairs_num = chairs_num;
  }
  o.set({
    ownData: ownData
  });

  //再渲染椅子座位
  if (type == 'desk') { //是桌子才能添加椅子这个地图元素

    console.log(o.toJSON());

    // const tl = o.oCoords.tl,
    //   tr = o.oCoords.tr,
    //   bl = o.oCoords.bl,
    //   br = o.oCoords.br,
    //   mt = o.oCoords.mt,
    //   mb = o.oCoords.mb,
    //   ml = o.oCoords.ml,
    //   mr = o.oCoords.mr;
    console.log(o.oCoords.tl, o.oCoords.tr, o.aCoords.bl, o.aCoords.br)
    // oCoords在经过画布缩放拖拽后不会更新，而使用setCoords()只会更新aCoords
    const tl = o.aCoords.tl,
      tr = o.aCoords.tr,
      bl = o.aCoords.bl,
      br = o.aCoords.br,
      mt = { x: tl.x + (tr.x - tl.x) / 2, y: tl.y + (tr.y - tl.y) / 2 },
      mb = { x: bl.x + (br.x - bl.x) / 2, y: bl.y + (br.y - bl.y) / 2 },
      ml = { x: tl.x + (bl.x - tl.x) / 2, y: tl.y + (bl.y - tl.y) / 2 },
      mr = { x: tr.x + (br.x - tr.x) / 2, y: tr.y + (br.y - tr.y) / 2 };
    const angle = o.toJSON().angle;
    console.log('angle==>', mt, mb, ml, mr, mr.x - ml.x)
    // 前后两个块的间隙
    var xblockLen = (mr.x - ml.x + 10 - 40) / 3;
    // 左右两点的距离+左右椅子的间距-中间两个椅子和宽(前后两个的距离)
    var xlrLength = ((mr.x - ml.x + 10 - 40) / 3 + 20);
    // y轴上下两个块的间隙
    var yblockLen = (mb.y - mt.y + 10 - 40) / 3;
    // y轴上下两点的距离+左右椅子的间距-中间两个椅子和宽(前后两个的距离)
    var ylrLength = ((mb.y - mt.y + 10 - 40) / 3 + 20);
    console.log(typeof xlrLength)
    console.log(typeof ylrLength)
    const r = 30;



    $('.edit_panel .num_2 input').each(function () {
      if (!$(this).val().match(/^[ ]*$/)) { //不是 空值且全是空格
        chairs_num.push($(this).val());
      }
    });

    switch (chairs_num.length) { //根据有多少张椅子来进行椅子包围桌子均匀布局(还未旋转情况下)
      case 0:
        break;
      case 1:
        console.log(xlrLength)
        var points = [];
        points[0] = {
          x: mt.x - 10,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 10,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 10,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x - 10,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });
        // 自定义属性保存时候避免丢失
        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        canvas.add(polygon);
        break;
      case 2:
        var points = [];
        points[0] = {
          x: mt.x - 10,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 10,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 10,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x - 10,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x - 10,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 10,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 10,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x - 10,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        break;
      case 3:
        var points = [];
        points[0] = {
          x: mt.x - 10,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 10,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 10,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x - 10,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x - 10,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 10,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 10,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x - 10,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        var points3 = [];
        points3[0] = {
          x: mr.x + 10,
          y: mr.y - 10
        };
        points3[1] = {
          x: mr.x + 30,
          y: mr.y - 10
        };
        points3[2] = {
          x: mr.x + 30,
          y: mr.y + 10
        };
        points3[3] = {
          x: mr.x + 10,
          y: mr.y + 10
        }
        var polygon3 = new fabric.Polygon(points3, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[2],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);
        polygon3.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon3.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        canvas.add(polygon3);
        break;
      case 4:
        var points = [];
        points[0] = {
          x: mt.x - 10,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 10,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 10,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x - 10,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x - 10,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 10,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 10,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x - 10,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        var points3 = [];
        points3[0] = {
          x: mr.x + 10,
          y: mr.y - 10
        };
        points3[1] = {
          x: mr.x + 30,
          y: mr.y - 10
        };
        points3[2] = {
          x: mr.x + 30,
          y: mr.y + 10
        };
        points3[3] = {
          x: mr.x + 10,
          y: mr.y + 10
        }
        var polygon3 = new fabric.Polygon(points3, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[2],
            father: name
          }
        });

        var points4 = [];
        points4[0] = {
          x: ml.x - 30,
          y: ml.y - 10
        };
        points4[1] = {
          x: ml.x - 10,
          y: ml.y - 10
        };
        points4[2] = {
          x: ml.x - 10,
          y: ml.y + 10
        };
        points4[3] = {
          x: ml.x - 30,
          y: ml.y + 10
        }
        var polygon4 = new fabric.Polygon(points4, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[3],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);
        polygon3.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon3.toObject);
        polygon4.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon4.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        canvas.add(polygon3);
        canvas.add(polygon4);
        break;
      case 5:
        var points = [];
        points[0] = {
          x: mt.x + xblockLen / 2,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 20 + xblockLen / 2,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 20 + xblockLen / 2,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x + xblockLen / 2,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x - 10,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 10,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 10,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x - 10,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        var points3 = [];
        points3[0] = {
          x: mr.x + 10,
          y: mr.y - 10
        };
        points3[1] = {
          x: mr.x + 30,
          y: mr.y - 10
        };
        points3[2] = {
          x: mr.x + 30,
          y: mr.y + 10
        };
        points3[3] = {
          x: mr.x + 10,
          y: mr.y + 10
        }
        var polygon3 = new fabric.Polygon(points3, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[2],
            father: name
          }
        });

        var points4 = [];
        points4[0] = {
          x: ml.x - 30,
          y: ml.y - 10
        };
        points4[1] = {
          x: ml.x - 10,
          y: ml.y - 10
        };
        points4[2] = {
          x: ml.x - 10,
          y: ml.y + 10
        };
        points4[3] = {
          x: ml.x - 30,
          y: ml.y + 10
        }
        var polygon4 = new fabric.Polygon(points4, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[3],
            father: name
          }
        });

        var points5 = [];
        points5[0] = {
          x: mt.x + xblockLen / 2 - xlrLength,
          y: mt.y - 30
        };
        points5[1] = {
          x: mt.x + 20 + xblockLen / 2 - xlrLength,
          y: mt.y - 30
        };
        points5[2] = {
          x: mt.x + 20 + xblockLen / 2 - xlrLength,
          y: mt.y - 10
        };
        points5[3] = {
          x: mt.x + xblockLen / 2 - xlrLength,
          y: mt.y - 10
        }
        var polygon5 = new fabric.Polygon(points5, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[4],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);
        polygon3.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon3.toObject);
        polygon4.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon4.toObject);
        polygon5.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon5.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        canvas.add(polygon3);
        canvas.add(polygon4);
        canvas.add(polygon5);
        break;
      case 6:
        var points = [];
        points[0] = {
          x: mt.x + xblockLen / 2,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 20 + xblockLen / 2,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 20 + xblockLen / 2,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x + xblockLen / 2,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x + xblockLen / 2,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 20 + xblockLen / 2,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 20 + xblockLen / 2,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x + xblockLen / 2,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        var points3 = [];
        points3[0] = {
          x: mr.x + 10,
          y: mr.y - 10
        };
        points3[1] = {
          x: mr.x + 30,
          y: mr.y - 10
        };
        points3[2] = {
          x: mr.x + 30,
          y: mr.y + 10
        };
        points3[3] = {
          x: mr.x + 10,
          y: mr.y + 10
        }
        var polygon3 = new fabric.Polygon(points3, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[2],
            father: name
          }
        });

        var points4 = [];
        points4[0] = {
          x: ml.x - 30,
          y: ml.y - 10
        };
        points4[1] = {
          x: ml.x - 10,
          y: ml.y - 10
        };
        points4[2] = {
          x: ml.x - 10,
          y: ml.y + 10
        };
        points4[3] = {
          x: ml.x - 30,
          y: ml.y + 10
        }
        var polygon4 = new fabric.Polygon(points4, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[3],
            father: name
          }
        });

        var points5 = [];
        points5[0] = {
          x: mt.x + xblockLen / 2 - xlrLength,
          y: mt.y - 30
        };
        points5[1] = {
          x: mt.x + 20 + xblockLen / 2 - xlrLength,
          y: mt.y - 30
        };
        points5[2] = {
          x: mt.x + 20 + xblockLen / 2 - xlrLength,
          y: mt.y - 10
        };
        points5[3] = {
          x: mt.x + xblockLen / 2 - xlrLength,
          y: mt.y - 10
        }
        var polygon5 = new fabric.Polygon(points5, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[4],
            father: name
          }
        });

        var points6 = [];
        points6[0] = {
          x: mb.x + xblockLen / 2 - xlrLength,
          y: mb.y + 10
        };
        points6[1] = {
          x: mb.x + 20 + xblockLen / 2 - xlrLength,
          y: mb.y + 10
        };
        points6[2] = {
          x: mb.x + 20 + xblockLen / 2 - xlrLength,
          y: mb.y + 30
        };
        points6[3] = {
          x: mb.x + xblockLen / 2 - xlrLength,
          y: mb.y + 30
        }
        var polygon6 = new fabric.Polygon(points6, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[5],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);
        polygon3.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon3.toObject);
        polygon4.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon4.toObject);
        polygon5.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon5.toObject);
        polygon6.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon6.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        canvas.add(polygon3);
        canvas.add(polygon4);
        canvas.add(polygon5);
        canvas.add(polygon6);
        break;
      case 7:
        var points = [];
        points[0] = {
          x: mt.x + xblockLen / 2,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 20 + xblockLen / 2,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 20 + xblockLen / 2,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x + xblockLen / 2,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x + xblockLen / 2,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 20 + xblockLen / 2,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 20 + xblockLen / 2,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x + xblockLen / 2,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        var points3 = [];
        points3[0] = {
          x: mr.x + 10,
          y: mr.y + yblockLen / 2
        };
        points3[1] = {
          x: mr.x + 30,
          y: mr.y + yblockLen / 2
        };
        points3[2] = {
          x: mr.x + 30,
          y: mr.y + 20 + yblockLen / 2
        };
        points3[3] = {
          x: mr.x + 10,
          y: mr.y + 20 + yblockLen / 2
        }
        var polygon3 = new fabric.Polygon(points3, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[2],
            father: name
          }
        });

        var points4 = [];
        points4[0] = {
          x: ml.x - 30,
          y: ml.y - 10
        };
        points4[1] = {
          x: ml.x - 10,
          y: ml.y - 10
        };
        points4[2] = {
          x: ml.x - 10,
          y: ml.y + 10
        };
        points4[3] = {
          x: ml.x - 30,
          y: ml.y + 10
        }
        var polygon4 = new fabric.Polygon(points4, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[3],
            father: name
          }
        });

        var points5 = [];
        points5[0] = {
          x: mt.x + xblockLen / 2 - xlrLength,
          y: mt.y - 30
        };
        points5[1] = {
          x: mt.x + 20 + xblockLen / 2 - xlrLength,
          y: mt.y - 30
        };
        points5[2] = {
          x: mt.x + 20 + xblockLen / 2 - xlrLength,
          y: mt.y - 10
        };
        points5[3] = {
          x: mt.x + xblockLen / 2 - xlrLength,
          y: mt.y - 10
        }
        var polygon5 = new fabric.Polygon(points5, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[4],
            father: name
          }
        });

        var points6 = [];
        points6[0] = {
          x: mb.x + xblockLen / 2 - xlrLength,
          y: mb.y + 10
        };
        points6[1] = {
          x: mb.x + 20 + xblockLen / 2 - xlrLength,
          y: mb.y + 10
        };
        points6[2] = {
          x: mb.x + 20 + xblockLen / 2 - xlrLength,
          y: mb.y + 30
        };
        points6[3] = {
          x: mb.x + xblockLen / 2 - xlrLength,
          y: mb.y + 30
        }
        var polygon6 = new fabric.Polygon(points6, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[5],
            father: name
          }
        });

        var points7 = [];
        points7[0] = {
          x: mr.x + 10,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points7[1] = {
          x: mr.x + 30,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points7[2] = {
          x: mr.x + 30,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        };
        points7[3] = {
          x: mr.x + 10,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        }
        var polygon7 = new fabric.Polygon(points7, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[6],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);
        polygon3.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon3.toObject);
        polygon4.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon4.toObject);
        polygon5.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon5.toObject);
        polygon6.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon6.toObject);
        polygon7.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon7.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        canvas.add(polygon3);
        canvas.add(polygon4);
        canvas.add(polygon5);
        canvas.add(polygon6);
        canvas.add(polygon7);
        break;
      case 8:
        var points = [];
        points[0] = {
          x: mt.x + xblockLen / 2,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 20 + xblockLen / 2,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 20 + xblockLen / 2,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x + xblockLen / 2,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x + xblockLen / 2,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 20 + xblockLen / 2,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 20 + xblockLen / 2,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x + xblockLen / 2,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        var points3 = [];
        points3[0] = {
          x: mr.x + 10,
          y: mr.y + yblockLen / 2
        };
        points3[1] = {
          x: mr.x + 30,
          y: mr.y + yblockLen / 2
        };
        points3[2] = {
          x: mr.x + 30,
          y: mr.y + 20 + yblockLen / 2
        };
        points3[3] = {
          x: mr.x + 10,
          y: mr.y + 20 + yblockLen / 2
        }
        var polygon3 = new fabric.Polygon(points3, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[2],
            father: name
          }
        });

        var points4 = [];
        points4[0] = {
          x: ml.x - 30,
          y: mr.y + yblockLen / 2
        };
        points4[1] = {
          x: ml.x - 10,
          y: mr.y + yblockLen / 2
        };
        points4[2] = {
          x: ml.x - 10,
          y: mr.y + 20 + yblockLen / 2
        };
        points4[3] = {
          x: ml.x - 30,
          y: mr.y + 20 + yblockLen / 2
        }
        var polygon4 = new fabric.Polygon(points4, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[3],
            father: name
          }
        });

        var points5 = [];
        points5[0] = {
          x: mt.x + xblockLen / 2 - xlrLength,
          y: mt.y - 30
        };
        points5[1] = {
          x: mt.x + 20 + xblockLen / 2 - xlrLength,
          y: mt.y - 30
        };
        points5[2] = {
          x: mt.x + 20 + xblockLen / 2 - xlrLength,
          y: mt.y - 10
        };
        points5[3] = {
          x: mt.x + xblockLen / 2 - xlrLength,
          y: mt.y - 10
        }
        var polygon5 = new fabric.Polygon(points5, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[4],
            father: name
          }
        });

        var points6 = [];
        points6[0] = {
          x: mb.x + xblockLen / 2 - xlrLength,
          y: mb.y + 10
        };
        points6[1] = {
          x: mb.x + 20 + xblockLen / 2 - xlrLength,
          y: mb.y + 10
        };
        points6[2] = {
          x: mb.x + 20 + xblockLen / 2 - xlrLength,
          y: mb.y + 30
        };
        points6[3] = {
          x: mb.x + xblockLen / 2 - xlrLength,
          y: mb.y + 30
        }
        var polygon6 = new fabric.Polygon(points6, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[5],
            father: name
          }
        });

        var points7 = [];
        points7[0] = {
          x: mr.x + 10,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points7[1] = {
          x: mr.x + 30,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points7[2] = {
          x: mr.x + 30,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        };
        points7[3] = {
          x: mr.x + 10,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        }
        var polygon7 = new fabric.Polygon(points7, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[6],
            father: name
          }
        });

        var points8 = [];
        points8[0] = {
          x: ml.x - 30,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points8[1] = {
          x: ml.x - 10,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points8[2] = {
          x: ml.x - 10,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        };
        points8[3] = {
          x: ml.x - 30,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        }
        var polygon8 = new fabric.Polygon(points8, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[7],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);
        polygon3.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon3.toObject);
        polygon4.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon4.toObject);
        polygon5.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon5.toObject);
        polygon6.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon6.toObject);
        polygon7.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon7.toObject);
        polygon8.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon8.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        canvas.add(polygon3);
        canvas.add(polygon4);
        canvas.add(polygon5);
        canvas.add(polygon6);
        canvas.add(polygon7);
        canvas.add(polygon8);
        break;
      case 9:
        var points = [];
        points[0] = {
          x: mt.x - 10,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 10,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 10,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x - 10,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x + xblockLen / 2,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 20 + xblockLen / 2,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 20 + xblockLen / 2,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x + xblockLen / 2,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        var points3 = [];
        points3[0] = {
          x: mr.x + 10,
          y: mr.y + yblockLen / 2
        };
        points3[1] = {
          x: mr.x + 30,
          y: mr.y + yblockLen / 2
        };
        points3[2] = {
          x: mr.x + 30,
          y: mr.y + 20 + yblockLen / 2
        };
        points3[3] = {
          x: mr.x + 10,
          y: mr.y + 20 + yblockLen / 2
        }
        var polygon3 = new fabric.Polygon(points3, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[2],
            father: name
          }
        });

        var points4 = [];
        points4[0] = {
          x: ml.x - 30,
          y: mr.y + yblockLen / 2
        };
        points4[1] = {
          x: ml.x - 10,
          y: mr.y + yblockLen / 2
        };
        points4[2] = {
          x: ml.x - 10,
          y: mr.y + 20 + yblockLen / 2
        };
        points4[3] = {
          x: ml.x - 30,
          y: mr.y + 20 + yblockLen / 2
        }
        var polygon4 = new fabric.Polygon(points4, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[3],
            father: name
          }
        });

        var points5 = [];
        points5[0] = {
          x: mt.x - 10 - xlrLength,
          y: mt.y - 30
        };
        points5[1] = {
          x: mt.x + 10 - xlrLength,
          y: mt.y - 30
        };
        points5[2] = {
          x: mt.x + 10 - xlrLength,
          y: mt.y - 10
        };
        points5[3] = {
          x: mt.x - 10 - xlrLength,
          y: mt.y - 10
        }
        var polygon5 = new fabric.Polygon(points5, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[4],
            father: name
          }
        });

        var points6 = [];
        points6[0] = {
          x: mb.x + xblockLen / 2 - xlrLength,
          y: mb.y + 10
        };
        points6[1] = {
          x: mb.x + 20 + xblockLen / 2 - xlrLength,
          y: mb.y + 10
        };
        points6[2] = {
          x: mb.x + 20 + xblockLen / 2 - xlrLength,
          y: mb.y + 30
        };
        points6[3] = {
          x: mb.x + xblockLen / 2 - xlrLength,
          y: mb.y + 30
        }
        var polygon6 = new fabric.Polygon(points6, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[5],
            father: name
          }
        });

        var points7 = [];
        points7[0] = {
          x: mr.x + 10,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points7[1] = {
          x: mr.x + 30,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points7[2] = {
          x: mr.x + 30,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        };
        points7[3] = {
          x: mr.x + 10,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        }
        var polygon7 = new fabric.Polygon(points7, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[6],
            father: name
          }
        });

        var points8 = [];
        points8[0] = {
          x: ml.x - 30,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points8[1] = {
          x: ml.x - 10,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points8[2] = {
          x: ml.x - 10,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        };
        points8[3] = {
          x: ml.x - 30,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        }
        var polygon8 = new fabric.Polygon(points8, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[7],
            father: name
          }
        });

        var points9 = [];
        points9[0] = {
          x: mt.x - 10 + xlrLength,
          y: mt.y - 30
        };
        points9[1] = {
          x: mt.x + 10 + xlrLength,
          y: mt.y - 30
        };
        points9[2] = {
          x: mt.x + 10 + xlrLength,
          y: mt.y - 10
        };
        points9[3] = {
          x: mt.x - 10 + xlrLength,
          y: mt.y - 10
        }
        var polygon9 = new fabric.Polygon(points9, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[8],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);
        polygon3.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon3.toObject);
        polygon4.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon4.toObject);
        polygon5.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon5.toObject);
        polygon6.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon6.toObject);
        polygon7.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon7.toObject);
        polygon8.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon8.toObject);
        polygon9.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon9.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        canvas.add(polygon3);
        canvas.add(polygon4);
        canvas.add(polygon5);
        canvas.add(polygon6);
        canvas.add(polygon7);
        canvas.add(polygon8);
        canvas.add(polygon9);
        break;
      case 10:
        var points = [];
        points[0] = {
          x: mt.x - 10,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 10,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 10,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x - 10,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x - 10,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 10,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 10,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x - 10,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        var points3 = [];
        points3[0] = {
          x: mr.x + 10,
          y: mr.y + yblockLen / 2
        };
        points3[1] = {
          x: mr.x + 30,
          y: mr.y + yblockLen / 2
        };
        points3[2] = {
          x: mr.x + 30,
          y: mr.y + 20 + yblockLen / 2
        };
        points3[3] = {
          x: mr.x + 10,
          y: mr.y + 20 + yblockLen / 2
        }
        var polygon3 = new fabric.Polygon(points3, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[2],
            father: name
          }
        });

        var points4 = [];
        points4[0] = {
          x: ml.x - 30,
          y: mr.y + yblockLen / 2
        };
        points4[1] = {
          x: ml.x - 10,
          y: mr.y + yblockLen / 2
        };
        points4[2] = {
          x: ml.x - 10,
          y: mr.y + 20 + yblockLen / 2
        };
        points4[3] = {
          x: ml.x - 30,
          y: mr.y + 20 + yblockLen / 2
        }
        var polygon4 = new fabric.Polygon(points4, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[3],
            father: name
          }
        });

        var points5 = [];
        points5[0] = {
          x: mt.x - 10 - xlrLength,
          y: mt.y - 30
        };
        points5[1] = {
          x: mt.x + 10 - xlrLength,
          y: mt.y - 30
        };
        points5[2] = {
          x: mt.x + 10 - xlrLength,
          y: mt.y - 10
        };
        points5[3] = {
          x: mt.x - 10 - xlrLength,
          y: mt.y - 10
        }
        var polygon5 = new fabric.Polygon(points5, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[4],
            father: name
          }
        });

        var points6 = [];
        points6[0] = {
          x: mb.x - 10 - xlrLength,
          y: mb.y + 10
        };
        points6[1] = {
          x: mb.x + 10 - xlrLength,
          y: mb.y + 10
        };
        points6[2] = {
          x: mb.x + 10 - xlrLength,
          y: mb.y + 30
        };
        points6[3] = {
          x: mb.x - 10 - xlrLength,
          y: mb.y + 30
        }
        var polygon6 = new fabric.Polygon(points6, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[5],
            father: name
          }
        });

        var points7 = [];
        points7[0] = {
          x: mr.x + 10,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points7[1] = {
          x: mr.x + 30,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points7[2] = {
          x: mr.x + 30,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        };
        points7[3] = {
          x: mr.x + 10,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        }
        var polygon7 = new fabric.Polygon(points7, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[6],
            father: name
          }
        });

        var points8 = [];
        points8[0] = {
          x: ml.x - 30,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points8[1] = {
          x: ml.x - 10,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points8[2] = {
          x: ml.x - 10,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        };
        points8[3] = {
          x: ml.x - 30,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        }
        var polygon8 = new fabric.Polygon(points8, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[7],
            father: name
          }
        });

        var points9 = [];
        points9[0] = {
          x: mt.x - 10 + xlrLength,
          y: mt.y - 30
        };
        points9[1] = {
          x: mt.x + 10 + xlrLength,
          y: mt.y - 30
        };
        points9[2] = {
          x: mt.x + 10 + xlrLength,
          y: mt.y - 10
        };
        points9[3] = {
          x: mt.x - 10 + xlrLength,
          y: mt.y - 10
        }
        var polygon9 = new fabric.Polygon(points9, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[8],
            father: name
          }
        });

        var points10 = [];
        points10[0] = {
          x: mb.x - 10 + xlrLength,
          y: mb.y + 10
        };
        points10[1] = {
          x: mb.x + 10 + xlrLength,
          y: mb.y + 10
        };
        points10[2] = {
          x: mb.x + 10 + xlrLength,
          y: mb.y + 30
        };
        points10[3] = {
          x: mb.x - 10 + xlrLength,
          y: mb.y + 30
        }
        var polygon10 = new fabric.Polygon(points10, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[9],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);
        polygon3.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon3.toObject);
        polygon4.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon4.toObject);
        polygon5.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon5.toObject);
        polygon6.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon6.toObject);
        polygon7.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon7.toObject);
        polygon8.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon8.toObject);
        polygon9.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon9.toObject);
        polygon10.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon10.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        canvas.add(polygon3);
        canvas.add(polygon4);
        canvas.add(polygon5);
        canvas.add(polygon6);
        canvas.add(polygon7);
        canvas.add(polygon8);
        canvas.add(polygon9);
        canvas.add(polygon10);
        break;
      case 11:
        var points = [];
        points[0] = {
          x: mt.x - 10,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 10,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 10,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x - 10,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x - 10,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 10,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 10,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x - 10,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        var points3 = [];
        points3[0] = {
          x: mr.x + 10,
          y: mr.y - 10
        };
        points3[1] = {
          x: mr.x + 30,
          y: mr.y - 10
        };
        points3[2] = {
          x: mr.x + 30,
          y: mr.y + 10
        };
        points3[3] = {
          x: mr.x + 10,
          y: mr.y + 10
        }
        var polygon3 = new fabric.Polygon(points3, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[2],
            father: name
          }
        });

        var points4 = [];
        points4[0] = {
          x: ml.x - 30,
          y: mr.y + yblockLen / 2
        };
        points4[1] = {
          x: ml.x - 10,
          y: mr.y + yblockLen / 2
        };
        points4[2] = {
          x: ml.x - 10,
          y: mr.y + 20 + yblockLen / 2
        };
        points4[3] = {
          x: ml.x - 30,
          y: mr.y + 20 + yblockLen / 2
        }
        var polygon4 = new fabric.Polygon(points4, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[3],
            father: name
          }
        });

        var points5 = [];
        points5[0] = {
          x: mt.x - 10 - xlrLength,
          y: mt.y - 30
        };
        points5[1] = {
          x: mt.x + 10 - xlrLength,
          y: mt.y - 30
        };
        points5[2] = {
          x: mt.x + 10 - xlrLength,
          y: mt.y - 10
        };
        points5[3] = {
          x: mt.x - 10 - xlrLength,
          y: mt.y - 10
        }
        var polygon5 = new fabric.Polygon(points5, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[4],
            father: name
          }
        });

        var points6 = [];
        points6[0] = {
          x: mb.x - 10 - xlrLength,
          y: mb.y + 10
        };
        points6[1] = {
          x: mb.x + 10 - xlrLength,
          y: mb.y + 10
        };
        points6[2] = {
          x: mb.x + 10 - xlrLength,
          y: mb.y + 30
        };
        points6[3] = {
          x: mb.x - 10 - xlrLength,
          y: mb.y + 30
        }
        var polygon6 = new fabric.Polygon(points6, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[5],
            father: name
          }
        });

        var points7 = [];
        points7[0] = {
          x: mr.x + 10,
          y: mr.y - 10 - ylrLength
        };
        points7[1] = {
          x: mr.x + 30,
          y: mr.y - 10 - ylrLength
        };
        points7[2] = {
          x: mr.x + 30,
          y: mr.y + 10 - ylrLength
        };
        points7[3] = {
          x: mr.x + 10,
          y: mr.y + 10 - ylrLength
        }
        var polygon7 = new fabric.Polygon(points7, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[6],
            father: name
          }
        });

        var points8 = [];
        points8[0] = {
          x: ml.x - 30,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points8[1] = {
          x: ml.x - 10,
          y: mr.y + yblockLen / 2 - ylrLength
        };
        points8[2] = {
          x: ml.x - 10,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        };
        points8[3] = {
          x: ml.x - 30,
          y: mr.y + 20 + yblockLen / 2 - ylrLength
        }
        var polygon8 = new fabric.Polygon(points8, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[7],
            father: name
          }
        });

        var points9 = [];
        points9[0] = {
          x: mt.x - 10 + xlrLength,
          y: mt.y - 30
        };
        points9[1] = {
          x: mt.x + 10 + xlrLength,
          y: mt.y - 30
        };
        points9[2] = {
          x: mt.x + 10 + xlrLength,
          y: mt.y - 10
        };
        points9[3] = {
          x: mt.x - 10 + xlrLength,
          y: mt.y - 10
        }
        var polygon9 = new fabric.Polygon(points9, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[8],
            father: name
          }
        });

        var points10 = [];
        points10[0] = {
          x: mb.x - 10 + xlrLength,
          y: mb.y + 10
        };
        points10[1] = {
          x: mb.x + 10 + xlrLength,
          y: mb.y + 10
        };
        points10[2] = {
          x: mb.x + 10 + xlrLength,
          y: mb.y + 30
        };
        points10[3] = {
          x: mb.x - 10 + xlrLength,
          y: mb.y + 30
        }
        var polygon10 = new fabric.Polygon(points10, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[9],
            father: name
          }
        });

        var points11 = [];
        points11[0] = {
          x: mr.x + 10,
          y: mr.y - 10 + ylrLength
        };
        points11[1] = {
          x: mr.x + 30,
          y: mr.y - 10 + ylrLength
        };
        points11[2] = {
          x: mr.x + 30,
          y: mr.y + 10 + ylrLength
        };
        points11[3] = {
          x: mr.x + 10,
          y: mr.y + 10 + ylrLength
        }
        var polygon11 = new fabric.Polygon(points11, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[10],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);
        polygon3.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon3.toObject);
        polygon4.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon4.toObject);
        polygon5.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon5.toObject);
        polygon6.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon6.toObject);
        polygon7.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon7.toObject);
        polygon8.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon8.toObject);
        polygon9.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon9.toObject);
        polygon10.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon10.toObject);
        polygon11.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon11.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        canvas.add(polygon3);
        canvas.add(polygon4);
        canvas.add(polygon5);
        canvas.add(polygon6);
        canvas.add(polygon7);
        canvas.add(polygon8);
        canvas.add(polygon9);
        canvas.add(polygon10);
        canvas.add(polygon11);
        break;
      case 12:
        var points = [];
        points[0] = {
          x: mt.x - 10,
          y: mt.y - 30
        };
        points[1] = {
          x: mt.x + 10,
          y: mt.y - 30
        };
        points[2] = {
          x: mt.x + 10,
          y: mt.y - 10
        };
        points[3] = {
          x: mt.x - 10,
          y: mt.y - 10
        }
        var polygon = new fabric.Polygon(points, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[0],
            father: name
          }
        });

        var points2 = [];
        points2[0] = {
          x: mb.x - 10,
          y: mb.y + 10
        };
        points2[1] = {
          x: mb.x + 10,
          y: mb.y + 10
        };
        points2[2] = {
          x: mb.x + 10,
          y: mb.y + 30
        };
        points2[3] = {
          x: mb.x - 10,
          y: mb.y + 30
        }
        var polygon2 = new fabric.Polygon(points2, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[1],
            father: name
          }
        });

        var points3 = [];
        points3[0] = {
          x: mr.x + 10,
          y: mr.y - 10
        };
        points3[1] = {
          x: mr.x + 30,
          y: mr.y - 10
        };
        points3[2] = {
          x: mr.x + 30,
          y: mr.y + 10
        };
        points3[3] = {
          x: mr.x + 10,
          y: mr.y + 10
        }
        var polygon3 = new fabric.Polygon(points3, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[2],
            father: name
          }
        });

        var points4 = [];
        points4[0] = {
          x: ml.x - 30,
          y: mr.y - 10
        };
        points4[1] = {
          x: ml.x - 10,
          y: mr.y - 10
        };
        points4[2] = {
          x: ml.x - 10,
          y: mr.y + 10
        };
        points4[3] = {
          x: ml.x - 30,
          y: mr.y + 10
        }
        var polygon4 = new fabric.Polygon(points4, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[3],
            father: name
          }
        });

        var points5 = [];
        points5[0] = {
          x: mt.x - 10 - xlrLength,
          y: mt.y - 30
        };
        points5[1] = {
          x: mt.x + 10 - xlrLength,
          y: mt.y - 30
        };
        points5[2] = {
          x: mt.x + 10 - xlrLength,
          y: mt.y - 10
        };
        points5[3] = {
          x: mt.x - 10 - xlrLength,
          y: mt.y - 10
        }
        var polygon5 = new fabric.Polygon(points5, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[4],
            father: name
          }
        });

        var points6 = [];
        points6[0] = {
          x: mb.x - 10 - xlrLength,
          y: mb.y + 10
        };
        points6[1] = {
          x: mb.x + 10 - xlrLength,
          y: mb.y + 10
        };
        points6[2] = {
          x: mb.x + 10 - xlrLength,
          y: mb.y + 30
        };
        points6[3] = {
          x: mb.x - 10 - xlrLength,
          y: mb.y + 30
        }
        var polygon6 = new fabric.Polygon(points6, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[5],
            father: name
          }
        });

        var points7 = [];
        points7[0] = {
          x: mr.x + 10,
          y: mr.y - 10 - ylrLength
        };
        points7[1] = {
          x: mr.x + 30,
          y: mr.y - 10 - ylrLength
        };
        points7[2] = {
          x: mr.x + 30,
          y: mr.y + 10 - ylrLength
        };
        points7[3] = {
          x: mr.x + 10,
          y: mr.y + 10 - ylrLength
        }
        var polygon7 = new fabric.Polygon(points7, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[6],
            father: name
          }
        });

        var points8 = [];
        points8[0] = {
          x: ml.x - 30,
          y: mr.y - 10 - ylrLength
        };
        points8[1] = {
          x: ml.x - 10,
          y: mr.y - 10 - ylrLength
        };
        points8[2] = {
          x: ml.x - 10,
          y: mr.y + 10 - ylrLength
        };
        points8[3] = {
          x: ml.x - 30,
          y: mr.y + 10 - ylrLength
        }
        var polygon8 = new fabric.Polygon(points8, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[7],
            father: name
          }
        });

        var points9 = [];
        points9[0] = {
          x: mt.x - 10 + xlrLength,
          y: mt.y - 30
        };
        points9[1] = {
          x: mt.x + 10 + xlrLength,
          y: mt.y - 30
        };
        points9[2] = {
          x: mt.x + 10 + xlrLength,
          y: mt.y - 10
        };
        points9[3] = {
          x: mt.x - 10 + xlrLength,
          y: mt.y - 10
        }
        var polygon9 = new fabric.Polygon(points9, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[8],
            father: name
          }
        });

        var points10 = [];
        points10[0] = {
          x: mb.x - 10 + xlrLength,
          y: mb.y + 10
        };
        points10[1] = {
          x: mb.x + 10 + xlrLength,
          y: mb.y + 10
        };
        points10[2] = {
          x: mb.x + 10 + xlrLength,
          y: mb.y + 30
        };
        points10[3] = {
          x: mb.x - 10 + xlrLength,
          y: mb.y + 30
        }
        var polygon10 = new fabric.Polygon(points10, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[9],
            father: name
          }
        });

        var points11 = [];
        points11[0] = {
          x: mr.x + 10,
          y: mr.y - 10 + ylrLength
        };
        points11[1] = {
          x: mr.x + 30,
          y: mr.y - 10 + ylrLength
        };
        points11[2] = {
          x: mr.x + 30,
          y: mr.y + 10 + ylrLength
        };
        points11[3] = {
          x: mr.x + 10,
          y: mr.y + 10 + ylrLength
        }
        var polygon11 = new fabric.Polygon(points11, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[10],
            father: name
          }
        });

        var points12 = [];
        points12[0] = {
          x: ml.x - 30,
          y: mr.y - 10 + ylrLength
        };
        points12[1] = {
          x: ml.x - 10,
          y: mr.y - 10 + ylrLength
        };
        points12[2] = {
          x: ml.x - 10,
          y: mr.y + 10 + ylrLength
        };
        points12[3] = {
          x: ml.x - 30,
          y: mr.y + 10 + ylrLength
        }
        var polygon12 = new fabric.Polygon(points12, {
          stroke: '#000',
          strokeWidth: 1,
          fill: '#C0E9FC',
          opacity: 1,
          lockScalingFlip: true,
          strokeUniform: true, //描边宽度不变
          ownData: {
            type: 'chair',
            name: chairs_num[10],
            father: name
          }
        });

        polygon.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon.toObject);
        polygon2.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon2.toObject);
        polygon3.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon3.toObject);
        polygon4.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon4.toObject);
        polygon5.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon5.toObject);
        polygon6.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon6.toObject);
        polygon7.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon7.toObject);
        polygon8.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon8.toObject);
        polygon9.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon9.toObject);
        polygon10.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon10.toObject);
        polygon11.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon11.toObject);
        polygon12.toObject = (function (toObject) {
          return function () {
            return fabric.util.object.extend(toObject.call(this), {
              curPoints: this.curPoints || null,
              ownData: this.ownData || null
            });
          };
        })(polygon12.toObject);

        canvas.add(polygon);
        canvas.add(polygon2);
        canvas.add(polygon3);
        canvas.add(polygon4);
        canvas.add(polygon5);
        canvas.add(polygon6);
        canvas.add(polygon7);
        canvas.add(polygon8);
        canvas.add(polygon9);
        canvas.add(polygon10);
        canvas.add(polygon11);
        canvas.add(polygon12);
        break;

      default:
        chairs_num.forEach(function (val) {
          var points = [];
          points[0] = {
            x: mt.x - 10,
            y: mt.y - 30
          };
          points[1] = {
            x: mt.x + 10,
            y: mt.y - 30
          };
          points[2] = {
            x: mt.x + 10,
            y: mt.y - 10
          };
          points[3] = {
            x: mt.x - 10,
            y: mt.y - 10
          }
          var polygon = new fabric.Polygon(points, {
            stroke: '#000',
            strokeWidth: 1,
            fill: '#C0E9FC',
            opacity: 1,
            lockScalingFlip: true,
            strokeUniform: true, //描边宽度不变
            ownData: {
              type: 'chair',
              name: val,
              father: name  //绑定的桌子/父元素的编号名称
            }
          });
          // 自定义属性保存时候避免丢失
          polygon.toObject = (function (toObject) {
            return function () {
              return fabric.util.object.extend(toObject.call(this), {
                curPoints: this.curPoints || null,
                ownData: this.ownData || null
              });
            };
          })(polygon.toObject);
          canvas.add(polygon);
        });
        break;

    }
  }

  if (type == 'room') {
    o.set({
      hoverCursor: 'default',
      opacity: 0.5,
      hasBorders: false,
      hasControls: false,
      selectable: false,
      lockMovementX: true,
      lockMovementY: true
    });
    canvas.moveTo(o, 0); //将它放在图层级的第0层，较底层,避免遮住房间里的元素
    // o.preserveObjectStacking = true; // 禁止选中图层时自动置于顶部(这个没用的，新版本应该废弃了)
  }

  regreshSonData(o); //刷新
  canvas.renderAll();

});
// 重置：
$('.edit_panel .footer>.reset').click(function () {
  console.log('reset');
  let obj = canvas.getActiveObject();
  initPanel(obj);
});
// 删除：
$('.edit_panel .footer>.delete').click(function () {
  // console.log(canvas.getActiveObject());
  let o = canvas.getActiveObject();
  if (o.ownData && o.ownData.father) {
    let name = o.ownData.name;
    let fatherName = o.ownData.father;

    canvas.getObjects().map(function (itemObj) { //根据它的父元素名字来查找它的父元素(绑定的桌子元素)
      if (itemObj.ownData && itemObj.ownData.name && itemObj.ownData.name == fatherName) {
        if (itemObj.ownData.chairs_num) {
          let index = itemObj.ownData.chairs_num.indexOf(name);
          itemObj.ownData.chairs_num.splice(index, 1); //删除这个桌子绑定的椅子数组中对应的椅子
        }
      }
    });
  }
  canvas.remove(o);
  $('.edit_panel').hide();
});

// 清除画布：
$('.top_box .clear_map').click(function () {
  canvas.clear();
  $('.edit_panel').hide();
});

// 保存地图数据：
var roomData = {
  floor: floor,
  arr: []
};
$('.top_box .save_map').click(function () {
  // console.log('保存地图数据');
  var mapData = getMap();
  // console.log('renderData:', mapData);
  var renderData = {
    floor: floor,
    mapData: mapData
  }
  console.log("renderData1===>", renderData)
  console.log("canvasData1===>", canvasData)
  // console.log('JSON.stringify之前请求需要传递的参数', renderData)
  renderData = JSON.stringify(renderData);
  canvasData = JSON.stringify(canvasData);
  console.log("renderData2===>", renderData)
  console.log("canvasData2===>", canvasData)

  // console.log('renderData保存之后请求需要传递的参数', renderData)

  // var data = {
  //   roomData: roomData,
  //   canvasData: canvasData,
  //   renderData: renderData
  // };

  startLoading();
  // $.ajax({
  //   type: "POST",
  //   url: "hhttp://192.168.31.38:3000/api/saveCan",
  //   contentType: 'application/json',
  //   data: renderData,
  //   success: function (res) {
  //     console.log("res1请求的数据===》", res);
  //   },
  //   error: function (err) {
  //     console.log("res1请求失败的数据===》", err);
  //   }
  // });

  $.ajax({
    type: "POST",
    url: saveMapUrl,
    contentType: 'application/json',
    data: renderData,
    success: function (res) {
      console.log("res请求的数据===》", res);
      window.open('http://192.168.31.38:3000/mapEdit_test/render.html');
      let t = setTimeout(function () {
        closeLoading();
        alert("保存成功！");
        window.clearTimeout(t);
      }, 500);
    },
    error: function (err) {
      console.log(err);
      let t = setTimeout(function () {
        closeLoading();
        alert("保存失败！");
        window.clearTimeout(t);
      }, 3000);
    }
  });
});

// 遍历当前画布地图获取数据：
function getMap() {
  console.log(canvas.toJSON());

  let basePoint = { //基于此室内坐标
    x: 100,
    y: 50
  }
  let geojson = {
    type: "FeatureCollection",
    features: []
  };
  let data = canvas.toJSON();
  let objArr = data.objects;
  console.log('data==>', data, "objArr==>", objArr, "我想要怒放的生命")

  objArr.forEach((val, i) => {
    // console.log(i, val);

    let ownData = val.ownData;

    let figureType = val.type || null; //图形类型
    let coordinate = []; //图形各个点的坐标集合

    let fillColor = val.fill || null; //填充颜色
    let weight = val.strokeWidth || 1; //描边大小
    let color = val.stroke || null; //描边颜色

    //多边形 计算该图形各个点的经纬度：
    if (figureType == 'polygon') {
      figureType = 'Polygon'; //注意：geoJSON数据中字段名首字母大写
      console.log('分界点不要超过')
      let points = val.curPoints || val.points;
      points.forEach((val2, i2) => {
        let x = basePoint.x + val2.x / 1000000;
        let y = basePoint.y + val2.y / 1000000;
        let res = GaussToBL(x, y); //室内坐标转成经纬度坐标
        // console.log('很多东西室内坐标沙达++》', basePoint.x, "++", val2.x, "++", x, "++", res)
        res[1] = -res[1]; //这里的坐标y即纬度在渲染时上下颠倒，所以处理一下
        coordinate.push(res);
      });
      //第一个点:
      let firstX = points[0].x;
      let firstY = points[0].y;
      //多增加最后一个点，与第一个点相同，代表闭合形状的点:
      let lastX = basePoint.x + firstX / 1000000;
      let lastY = basePoint.y + firstY / 1000000;
      let res = GaussToBL(lastX, lastY);
      res[1] = -res[1]; //这里的坐标y即纬度在渲染时上下颠倒，所以处理一下
      coordinate.push(res);
    }

    //图片图标
    if (figureType == 'image') {
      figureType = 'Point';
      let x = basePoint.x + (val.left + val.width * val.scaleX / 2) / 1000000;
      let y = basePoint.y + (val.top + val.height * val.scaleY / 2) / 1000000;
      let res = GaussToBL(x, y);
      res[1] = -res[1];
      coordinate = res;
    }

    // 统一数据结构，与渲染框架leaflet所需的geojosn数据结构一致
    let item = {
      type: 'Feature',
      properties: {
        color,
        weight,
        fillColor,
        ownData
      },
      geometry: {
        type: figureType,
        coordinates: figureType == 'Point' ? coordinate : [coordinate]
      }
    };
    // console.log(item);
    geojson.features.push(item);
    if (ownData) {
      if (ownData.type && ownData.type == 'desk') { //保存桌子数据
        roomData.arr.push(ownData);
      }
      if (ownData.type && ownData.type == 'chair' && (!ownData.father)) { //保存零散的没绑定桌子的椅子数据
        roomData.arr.push(ownData);
      }
    }

  });

  canvas.clear();
  console.log("1594行canvas=data=>,", data)
  // 给移动的位置来个初始化，防止移动后位置变回去
  canvas.loadFromJSON(data, canvas.renderAll.bind(canvas), function (o, polygon) {
    polygon.toObject = (function (toObject) {
      return function () {
        return fabric.util.object.extend(toObject.call(this), {
          curPoints: this.curPoints || null,
          ownData: this.ownData || null
        });
      };
    })(polygon.toObject);
  });
  canvasData = data;

  console.log('geojson:', geojson, "1600行的data=>", data);
  // console.log('roomData:', roomData);
  return geojson;
}

// Loading：
function startLoading() {
  $('.loading').show();
}
function closeLoading() {
  $('.loading').hide();
}


// 页面初始化
window.onload = function () {
  // 获取地图数据并渲染：
  // canvas.clear();
  // let rq_data = 'floor=12';
  // startLoading();
  // $.ajax({
  //   url: getCanvasUrl,
  //   data: rq_data,
  //   success: function (res) {
  //     console.log(res);
  //     canvasData = res.data;
  //     canvas.loadFromJSON(canvasData, canvas.renderAll.bind(canvas));
  //   },
  //   error: function (err) {
  //     console.log('err: ', err);
  //     alert('获取数据失败！');
  //   },
  //   complete: function () {
  //     closeLoading();
  //   }
  // })

  setTimeout(function () {
    let load = document.getElementsByClassName('loading')[0];
    load.setAttribute('style', 'display: none')
    // console.log('定时器你执行了几次', load)
  }, 100)

}