//本地地图数据渲染
var mapData_1 = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {},
      "geometry": {
        "type": "Polygon",
        "coordinates": [
          [
            [100, 50],
            [100.001, 50],
            [100.001, 50.001],
            [100, 50.001],
            [100, 50]
          ]
        ]
      }
    }
  ]
};

var map = L.map('map', {
  center: [-0.000450794771905835, -7.486054440093591], //[纬度， 经度]（顺序注意）
  zoom: 37,
  // maxBounds: [[99.998, 99.998], [100.002, 100.002]] //最大范围限制(矩形范围的对角两个点坐标)
});

var danYuanMian_geoJSON;

var geojsonUrl = './jsonData/map_2.json';
var mapJson_1 = {};
$.ajax({
  timeout: 6E4,
  type: "GET",
  url: geojsonUrl,
  dataType: "text",
  success: function (res) {
    // console.log(JSON.stringify(res[0]['data']));
    // mapJson_1 = eval("(" + JSON.stringify(res[0]['data']) + ")");//将string转化为json
    // console.log(res);
    mapJson_1 = eval("(" + res + ")");//将string转化为json

    var collisionLayer = L.LayerGroup.collision({ margin: 7 });//公共点碰撞
    var collisionLayer2 = L.LayerGroup.collision({ margin: 15 });//单元面商标和名称碰撞

    danYuanMian_geoJSON = L.geoJSON(mapJson_1.mapData, {
      style: function (feature) {
        let color = feature.properties.color || '#aaa';
        let weight = feature.properties.weight || 1;
        let fillOpacity = feature.properties.opacity || 1;
        let fillColor = feature.properties.fillColor || '#C0E9FC';
        return {
          color,
          weight,
          fillOpacity,
          fillColor
        };
      },
      pointToLayer: function (feature, latlng) {

        var styleIcon = {
          name: "圆桌",
          iconUrl: './static/images/yz_01.png',
          iconSize: [22, 22],
          iconAnchor: [11, 11]
        };
        if (feature.properties.ownData && feature.properties.ownData.curIcon) {
          styleIcon.name = feature.properties.ownData.curIcon;
        }
        if (feature.properties.ownData && feature.properties.ownData.curIconSrc) {
          styleIcon.iconUrl = feature.properties.ownData.curIconSrc;
        }
        var icon = L.icon(styleIcon);
        var marker = L.marker(latlng, { icon: icon });
        collisionLayer.addLayer(marker);//公共点碰撞
        return marker;
      },
      onEachFeature: function (feature, layer) {

        if (feature.geometry.type == 'Polygon') {
          var polygon = feature.geometry.coordinates;
          var p = polylabel(polygon, 0.5);//获取单元面中心点坐标polylabel.js

          //给单元面添加商标和名称
          var baseballIcon = L.icon({
            name: "商标",
            iconUrl: './static/images/yzIcon_01.png',
            iconSize: [20, 20],
            iconAnchor: [10, 22]
          });
          var ownData = layer.feature.properties.ownData || null;
          if (feature.properties.ownData && feature.properties.ownData.curIcon) {
            baseballIcon.options.name = feature.properties.ownData.curIcon;
            // baseballIcon.name = feature.properties.ownData.curIcon;
          }
          if (feature.properties.ownData && feature.properties.ownData.curIconSrc) {
            baseballIcon.options.iconUrl = feature.properties.ownData.curIconSrc;
            // baseballIcon.iconUrl = feature.properties.ownData.curIconSrc;
            // console.log(feature.properties.ownData.curIconSrc);
            // console.log(baseballIcon);
          }
          if (layer.feature.properties && ownData && ownData.name) {
            var NAME = ownData.name;
            var logolable = L.marker([p[1], p[0]], {
              icon: baseballIcon,
              opacity: 0,
              interactive: false
            }).bindTooltip(NAME, { className: 'mytip_1', interactive: false, permanent: true, direction: 'center', offset: [0, 5] })
            collisionLayer2.addLayer(logolable);//单元面商标和名称碰撞
            logolable.addTo(map);
          }
          // 给单元面添加事件
          layer.on({
            // mouseover: highlightFeature,//手机不适用
            // mouseout: resetHighlight,//手机不适用
            click: clickToFeature
          });
        }
      }
    }).addTo(map);
    collisionLayer2.addTo(map);//单元面商标和名称碰撞
  }
})

var hasClickFeature = false;//是否点击过了
var preClickFeature; //记录上一个点击的单元面
// 点击单元：
function clickToFeature(e) {
  //点击高亮单元面
  if (hasClickFeature) {
    danYuanMian_geoJSON.resetStyle(preClickFeature.target);
    highlightFeature(e);
    preClickFeature = e;
  } else {
    //第一次点击
    preClickFeature = e;
    highlightFeature(e);
    hasClickFeature = true;
  }


  /*//添加开始marker标记
   if (hasStartPoint) {
   startPoint.remove();
   //            console.log(e);
   //startPoint = L.marker(e.latlng);//鼠标点击单元面的点
   startPoint = L.marker(e.target.getCenter());//单元面中点,有问题:对于凹型面,可能不打在面上,tooltip也存在这样的问题
   startPoint.addTo(map);
   } else {
   //第一次点击
   startPoint = L.marker(e.target.getCenter());
   startPoint.addTo(map);
   hasStartPoint = true;
   }
   //console.log(hasStartPoint);*/


  //地图放大聚焦到点击的单元面,缩放变为Zoom:20
  //map.fitBounds(e.target.getBounds(),{maxZoom:19});


  //单元面详细信息展示
  // $(".description").slideDown('fast');//展开
  // $(".description").click(function () {
  //   $(".description").slideUp('fast');//收起
  // });
  // if (e.target.feature.properties && e.target.feature.properties.NAME) {
  //   var name = e.target.feature.properties.NAME;
  // } else {
  //   var name = "未知"
  // }
  // //console.log(e.target.feature.properties.NAME);
  // $("#NAME").text(name);

  // //收起切换楼层块
  // if ($(".floor-choose-box .floor-choose-div").is(":visible")) {
  //   $(".floor-choose-box .floor-choose-div").slideUp('fast');//收起
  // }
}


// 单元面 高亮显示：
function highlightFeature(e) {
  var layer = e.target;

  layer.setStyle({
    weight: 3,
    color: '#03a9f4',
    dashArray: '',
    fillColor: "yellow",
    fillOpacity: 0.5
  });

  if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
    layer.bringToFront();
  }
}

