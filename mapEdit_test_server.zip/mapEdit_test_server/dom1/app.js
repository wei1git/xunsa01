var fs = require('fs');
var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var bodyParser = require('body-parser');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/api/saveMap', function (req, res) {

  var data = req.body;
  console.log(data);
  var floor = data.floor;
  var mapData = data.mapData;
  // console.log(mapData);
  console.log(mapData.features[0].geometry.coordinates[0][0]);
  // 将数据存储到json文件中：
  let str = JSON.stringify(data, null, "\t");
  // console.log(str);
  fs.writeFile('public/mapEdit_test/jsonData/map_2.json', str, function (err) {
    if (err) {
      res.status(500).send('服务器保存数据错误...');
      return;
    }
  });
  res.send(req.body);
});

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});



module.exports = app;
